function initialize() {
	cardBackSrc = "img/cardback.png";

	card1 = document.getElementById("card1");
	card2 = document.getElementById("card2");
	card3 = document.getElementById("card3");
	card4 = document.getElementById("card4");

	card5 = document.getElementById("card5");
	card6 = document.getElementById("card6");
	card7 = document.getElementById("card7");
	card8 = document.getElementById("card8");

	card9 = document.getElementById("card9");
	card10 = document.getElementById("card10");
	card11 = document.getElementById("card11");
	card12 = document.getElementById("card12");

	card13 = document.getElementById("card13");
	card14 = document.getElementById("card14");
	card15 = document.getElementById("card15");
	card16 = document.getElementById("card16");


	scoreDisplay = document.getElementById("scoreDisplay");
	messages = document.getElementById("messages")


	// source img for each card
	card1Src = "img/cardA.png";
	card2Src = "img/cardA.png";
	card3Src = "img/cardB.png";
	card4Src = "img/cardB.png";

	card5Src = "img/cardC.png";
	card6Src = "img/cardC.png";
	card7Src = "img/cardD.png";
	card8Src = "img/cardD.png";

	card9Src = "img/cardE.png";
	card10Src = "img/cardE.png";
	card11Src = "img/cardF.png";
	card12Src = "img/cardF.png";

	card13Src = "img/cardG.png";
	card14Src = "img/cardG.png";
	card15Src = "img/cardH.png";
	card16Src = "img/cardH.png";


	// 0 for not flipped; 1 for is flipped; 2 for matching pair found
	card1Flipped = 0;
	card2Flipped = 0;
	card3Flipped = 0;
	card4Flipped = 0;

	card5Flipped = 0;
	card6Flipped = 0;
	card7Flipped = 0;
	card8Flipped = 0;

	card9Flipped = 0;
	card10Flipped = 0;
	card11Flipped = 0;
	card12Flipped = 0;

	card13Flipped = 0;
	card14Flipped = 0;
	card15Flipped = 0;
	card16Flipped = 0;

	score = 0;
	gameOver = false;

	display();
}


function flipCard(num) {
	if (num == "1" && card1Flipped == 0) {
		card1.src = card1Src;
		card1Flipped = 1;
	} else if (num == "1" && card1Flipped == 1) {
		card1.src = cardBackSrc;
		card1Flipped = 0;
	}

	if (num == "2" && card2Flipped == 0) {
		card2.src = card2Src;
		card2Flipped = 1;
	} else if (num == "2" && card2Flipped == 1) {
		card2.src = cardBackSrc;
		card2Flipped = 0;
	}

	if (num == "3" && card3Flipped == 0) {
		card3.src = card3Src;
		card3Flipped = 1;
	} else if (num == "3" && card3Flipped == 1) {
		card3.src = cardBackSrc;
		card3Flipped = 0;
	}

	if (num == "4" && card4Flipped == 0) {
		card4.src = card4Src;
		card4Flipped = 1;
	} else if (num == "4" && card4Flipped == 1) {
		card4.src = cardBackSrc;
		card4Flipped = 0;
	}

	if (num == "5" && card5Flipped == 0) {
		card5.src = card5Src;
		card5Flipped = 1;
	} else if (num == "5" && card5Flipped == 1) {
		card5.src = cardBackSrc;
		card5Flipped = 0;
	}

	if (num == "6" && card6Flipped == 0) {
		card6.src = card6Src;
		card6Flipped = 1;
	} else if (num == "6" && card6Flipped == 1) {
		card6.src = cardBackSrc;
		card6Flipped = 0;
	}

	if (num == "7" && card7Flipped == 0) {
		card7.src = card7Src;
		card7Flipped = 1;
	} else if (num == "7" && card7Flipped == 1) {
		card7.src = cardBackSrc;
		card7Flipped = 0;
	}

	if (num == "8" && card8Flipped == 0) {
		card8.src = card8Src;
		card8Flipped = 1;
	} else if (num == "8" && card8Flipped == 1) {
		card8.src = cardBackSrc;
		card8Flipped = 0;
	}

	if (num == "9" && card9Flipped == 0) {
		card9.src = card9Src;
		card9Flipped = 1;
	} else if (num == "9" && card9Flipped == 1) {
		card9.src = cardBackSrc;
		card9Flipped = 0;
	}

	if (num == "10" && card10Flipped == 0) {
		card10.src = card10Src;
		card10Flipped = 1;
	} else if (num == "10" && card10Flipped == 1) {
		card10.src = cardBackSrc;
		card10Flipped = 0;
	}

	if (num == "11" && card11Flipped == 0) {
		card11.src = card11Src;
		card11Flipped = 1;
	} else if (num == "11" && card11Flipped == 1) {
		card11.src = cardBackSrc;
		card11Flipped = 0;
	}

	if (num == "12" && card12Flipped == 0) {
		card12.src = card12Src;
		card12Flipped = 1;
	} else if (num == "12" && card12Flipped == 1) {
		card12.src = cardBackSrc;
		card12Flipped = 0;
	}

	if (num == "13" && card13Flipped == 0) {
		card13.src = card13Src;
		card13Flipped = 1;
	} else if (num == "13" && card13Flipped == 1) {
		card13.src = cardBackSrc;
		card13Flipped = 0;
	}

	if (num == "14" && card14Flipped == 0) {
		card14.src = card14Src;
		card14Flipped = 1;
	} else if (num == "14" && card14Flipped == 1) {
		card14.src = cardBackSrc;
		card14Flipped = 0;
	}

	if (num == "15" && card15Flipped == 0) {
		card15.src = card15Src;
		card15Flipped = 1;
	} else if (num == "15" && card15Flipped == 1) {
		card15.src = cardBackSrc;
		card15Flipped = 0;
	}

	if (num == "16" && card16Flipped == 0) {
		card16.src = card16Src;
		card16Flipped = 1;
	} else if (num == "16" && card16Flipped == 1) {
		card16.src = cardBackSrc;
		card16Flipped = 0;
	}

	score += 1;

	checkCardMatches();

	display();
}


function checkCardMatches() {
	if (card1Flipped == 1 && card2Flipped == 1) {
		card1Flipped = 2;
		card2Flipped = 2;
	}

	if (card3Flipped == 1 && card4Flipped == 1) {
		card3Flipped = 2;
		card4Flipped = 2;
	}

	if (card5Flipped == 1 && card6Flipped == 1) {
		card5Flipped = 2;
		card6Flipped = 2;
	}
	
	if (card7Flipped == 1 && card8Flipped == 1) {
		card7Flipped = 2;
		card8Flipped = 2;
	}

	if (card9Flipped == 1 && card10Flipped == 1) {
		card9Flipped = 2;
		card10Flipped = 2;
	}

	if (card11Flipped == 1 && card12Flipped == 1) {
		card11Flipped = 2;
		card12Flipped = 2;
	}

	if (card13Flipped == 1 && card14Flipped == 1) {
		card13Flipped = 2;
		card14Flipped = 2;
	}

	if (card15Flipped == 1 && card16Flipped == 1) {
		card15Flipped = 2;
		card16Flipped = 2;
	}


	if (card1Flipped == 2 &&
		card2Flipped == 2 &&
		card3Flipped == 2 &&
		card4Flipped == 2 &&
		card5Flipped == 2 &&
		card6Flipped == 2 &&
		card7Flipped == 2 &&
		card8Flipped == 2 &&
		card9Flipped == 2 &&
		card10Flipped == 2 &&
		card11Flipped == 2 &&
		card12Flipped == 2 &&
		card13Flipped == 2 &&
		card14Flipped == 2 &&
		card15Flipped == 2 &&
		card16Flipped == 2)
	{
		gameOver = true;
	}

	display();
}


function display() {
	scoreDisplay.innerHTML = score;

	if (gameOver) {
		messages.innerHTML = "You win!";
	}
}
