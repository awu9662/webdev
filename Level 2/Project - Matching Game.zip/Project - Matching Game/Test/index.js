function initialize() {
	cardBackSrc = "img/cardback.png";

	card1 = document.getElementById("card1");
	card2 = document.getElementById("card2");
	card3 = document.getElementById("card3");
	card4 = document.getElementById("card4");

	card5 = document.getElementById("card5");
	card6 = document.getElementById("card6");
	card7 = document.getElementById("card7");
	card8 = document.getElementById("card8");

	card9 = document.getElementById("card9");
	card10 = document.getElementById("card1");
	card11 = document.getElementById("card1");
	card12 = document.getElementById("card1");

	card13 = document.getElementById("card1");
	card14 = document.getElementById("card1");
	card15 = document.getElementById("card1");
	card16 = document.getElementById("card1");

	card1Flipped = false;
	card2Flipped = false;
	card3Flipped = false;
	card4Flipped = false;

	card5Flipped = false;
	card6Flipped = false;
	card7Flipped = false;
	card8Flipped = false;

	card9Flipped = false;
	card10Flipped = false;
	card11Flipped = false;
	card12Flipped = false;

	card13Flipped = false;
	card14Flipped = false;
	card15Flipped = false;
	card16Flipped = false;
}


function flipImage(num) {
	if (num == '1' && !card1Flipped) {
		card1.src = "img/cardA.png";
		card1Flipped = true;
	} else if (num == '1' && card1Flipped) {
		card1.src = cardBackSrc;
		card1Flipped = false;
	}
}
