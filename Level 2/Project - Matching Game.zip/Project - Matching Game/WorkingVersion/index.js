function initialize() {
  cardBackSrc = "img/cardback.png";

  card1 = document.getElementById("card1");
  card2 = document.getElementById("card2");
  card3 = document.getElementById("card3");
  card4 = document.getElementById("card4");

  card5 = document.getElementById("card5");
  card6 = document.getElementById("card6");
  card7 = document.getElementById("card7");
  card8 = document.getElementById("card8");

  card9 = document.getElementById("card9");
  card10 = document.getElementById("card10");
  card11 = document.getElementById("card11");
  card12 = document.getElementById("card12");

  card13 = document.getElementById("card13");
  card14 = document.getElementById("card14");
  card15 = document.getElementById("card15");
  card16 = document.getElementById("card16");

  scoreDisplay = document.getElementById("scoreDisplay");
  messages = document.getElementById("messages");

  // source img for each card
  card1Src = "img/cardA.png";
  card2Src = "img/cardA.png";
  card3Src = "img/cardB.png";
  card4Src = "img/cardB.png";

  card5Src = "img/cardC.png";
  card6Src = "img/cardC.png";
  card7Src = "img/cardD.png";
  card8Src = "img/cardD.png";

  card9Src = "img/cardE.png";
  card10Src = "img/cardE.png";
  card11Src = "img/cardF.png";
  card12Src = "img/cardF.png";

  card13Src = "img/cardG.png";
  card14Src = "img/cardG.png";
  card15Src = "img/cardH.png";
  card16Src = "img/cardH.png";

  // 0 for not flipped; 1 for is flipped; 2 for matching pair found
  card1Flipped = 0;
  card2Flipped = 0;
  card3Flipped = 0;
  card4Flipped = 0;

  card5Flipped = 0;
  card6Flipped = 0;
  card7Flipped = 0;
  card8Flipped = 0;

  card9Flipped = 0;
  card10Flipped = 0;
  card11Flipped = 0;
  card12Flipped = 0;

  card13Flipped = 0;
  card14Flipped = 0;
  card15Flipped = 0;
  card16Flipped = 0;

  currentImagesFlipped = 0;
  score = 0;
  gameOver = false;

  display();
}

function flipCard(num) {
  /* keep two images flipped at most and
  turn over the others ones when a third is pressed
  unless the image has a match */
  if (currentImagesFlipped == 2) {

    if (card1Flipped != 2) card1Flipped = 0;
    if (card2Flipped != 2) card2Flipped = 0;
    if (card3Flipped != 2) card3Flipped = 0;
    if (card4Flipped != 2) card4Flipped = 0;
    if (card5Flipped != 2) card5Flipped = 0;
    if (card6Flipped != 2) card6Flipped = 0;
    if (card7Flipped != 2) card7Flipped = 0;
    if (card8Flipped != 2) card8Flipped = 0;
    if (card9Flipped != 2) card9Flipped = 0;
    if (card10Flipped != 2) card10Flipped = 0;
    if (card11Flipped != 2) card11Flipped = 0;
    if (card12Flipped != 2) card12Flipped = 0;
    if (card13Flipped != 2) card13Flipped = 0;
    if (card14Flipped != 2) card14Flipped = 0;
    if (card15Flipped != 2) card15Flipped = 0;
    if (card16Flipped != 2) card16Flipped = 0;

    currentImagesFlipped = 0;
  }

  var flippedAnImage = false;

  if (num == "1" && card1Flipped == 0) {
    card1Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "2" && card2Flipped == 0) {
    card2Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "3" && card3Flipped == 0) {
    card3Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "4" && card4Flipped == 0) {
    card4Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "5" && card5Flipped == 0) {
    card5Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "6" && card6Flipped == 0) {
    card6Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "7" && card7Flipped == 0) {
    card7Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "8" && card8Flipped == 0) {
    card8Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "9" && card9Flipped == 0) {
    card9Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "10" && card10Flipped == 0) {
    card10Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "11" && card11Flipped == 0) {
    card11Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "12" && card12Flipped == 0) {
    card12Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "13" && card13Flipped == 0) {
    card13Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "14" && card14Flipped == 0) {
    card14Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "15" && card15Flipped == 0) {
    card15Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "16" && card16Flipped == 0) {
    card16Flipped = 1;
    flippedAnImage = true;
  }

  if (flippedAnImage) {
    score += 1;
    currentImagesFlipped += 1;
  }

  checkCardMatches();

  display();
}

function checkCardMatches() {
  if (card1Flipped == 1 && card2Flipped == 1) {
    card1Flipped = 2;
    card2Flipped = 2;
  }

  if (card3Flipped == 1 && card4Flipped == 1) {
    card3Flipped = 2;
    card4Flipped = 2;
  }

  if (card5Flipped == 1 && card6Flipped == 1) {
    card5Flipped = 2;
    card6Flipped = 2;
  }

  if (card7Flipped == 1 && card8Flipped == 1) {
    card7Flipped = 2;
    card8Flipped = 2;
  }

  if (card9Flipped == 1 && card10Flipped == 1) {
    card9Flipped = 2;
    card10Flipped = 2;
  }

  if (card11Flipped == 1 && card12Flipped == 1) {
    card11Flipped = 2;
    card12Flipped = 2;
  }

  if (card13Flipped == 1 && card14Flipped == 1) {
    card13Flipped = 2;
    card14Flipped = 2;
  }

  if (card15Flipped == 1 && card16Flipped == 1) {
    card15Flipped = 2;
    card16Flipped = 2;
  }

	// check if every card matches
  if (
    card1Flipped == 2 &&
    card2Flipped == 2 &&
    card3Flipped == 2 &&
    card4Flipped == 2 &&
    card5Flipped == 2 &&
    card6Flipped == 2 &&
    card7Flipped == 2 &&
    card8Flipped == 2 &&
    card9Flipped == 2 &&
    card10Flipped == 2 &&
    card11Flipped == 2 &&
    card12Flipped == 2 &&
    card13Flipped == 2 &&
    card14Flipped == 2 &&
    card15Flipped == 2 &&
    card16Flipped == 2
  ) {
    gameOver = true;
  }

  display();
}

function reset() {
	card1Flipped = 0;
  card2Flipped = 0;
  card3Flipped = 0;
  card4Flipped = 0;

  card5Flipped = 0;
  card6Flipped = 0;
  card7Flipped = 0;
  card8Flipped = 0;

  card9Flipped = 0;
  card10Flipped = 0;
  card11Flipped = 0;
  card12Flipped = 0;

  card13Flipped = 0;
  card14Flipped = 0;
  card15Flipped = 0;
  card16Flipped = 0;

  currentImagesFlipped = 0;
  score = 0;
	gameOver = false;

	messages.innerHTML = "";

	display();
}

function display() {
  if (card1Flipped == 1 || card1Flipped == 2) {
    card1.src = card1Src;
  } else {
    card1.src = cardBackSrc;
  }

  if (card2Flipped == 1 || card2Flipped == 2) {
    card2.src = card2Src;
  } else {
    card2.src = cardBackSrc;
  }

  if (card3Flipped == 1 || card3Flipped == 2) {
    card3.src = card3Src;
  } else {
    card3.src = cardBackSrc;
  }

  if (card4Flipped == 1 || card4Flipped == 2) {
    card4.src = card4Src;
  } else {
    card4.src = cardBackSrc;
  }

  if (card5Flipped == 1 || card5Flipped == 2) {
    card5.src = card5Src;
  } else {
    card5.src = cardBackSrc;
  }

  if (card6Flipped == 1 || card6Flipped == 2) {
    card6.src = card6Src;
  } else {
    card6.src = cardBackSrc;
  }

  if (card7Flipped == 1 || card7Flipped == 2) {
    card7.src = card7Src;
  } else {
    card7.src = cardBackSrc;
  }

  if (card8Flipped == 1 || card8Flipped == 2) {
    card8.src = card8Src;
  } else {
    card8.src = cardBackSrc;
  }

  if (card9Flipped == 1 || card9Flipped == 2) {
    card9.src = card9Src;
  } else {
    card9.src = cardBackSrc;
  }

  if (card10Flipped == 1 || card10Flipped == 2) {
    card10.src = card10Src;
  } else {
    card10.src = cardBackSrc;
  }

  if (card11Flipped == 1 || card11Flipped == 2) {
    card11.src = card11Src;
  } else {
    card11.src = cardBackSrc;
  }

  if (card12Flipped == 1 || card12Flipped == 2) {
    card12.src = card12Src;
  } else {
    card12.src = cardBackSrc;
  }

  if (card13Flipped == 1 || card13Flipped == 2) {
    card13.src = card13Src;
  } else {
    card13.src = cardBackSrc;
  }

  if (card14Flipped == 1 || card14Flipped == 2) {
    card14.src = card14Src;
  } else {
    card14.src = cardBackSrc;
  }

  if (card15Flipped == 1 || card15Flipped == 2) {
    card15.src = card15Src;
  } else {
    card15.src = cardBackSrc;
  }

  if (card16Flipped == 1 || card16Flipped == 2) {
    card16.src = card16Src;
  } else {
    card16.src = cardBackSrc;
  }

  scoreDisplay.innerHTML = score;

  if (gameOver) {
    messages.innerHTML = "You win!";
  }
}
