function initialize() {
  cardBackSrc = "img/cardback.png";

  card1 = document.getElementById("card1");
  card2 = document.getElementById("card2");
  card3 = document.getElementById("card3");
  card4 = document.getElementById("card4");

  card5 = document.getElementById("card5");
  card6 = document.getElementById("card6");
  card7 = document.getElementById("card7");
  card8 = document.getElementById("card8");

  card9 = document.getElementById("card9");
  card10 = document.getElementById("card10");
  card11 = document.getElementById("card11");
  card12 = document.getElementById("card12");

  card13 = document.getElementById("card13");
  card14 = document.getElementById("card14");
  card15 = document.getElementById("card15");
  card16 = document.getElementById("card16");

  scoreDisplay = document.getElementById("scoreDisplay");
  messages = document.getElementById("messages");

  // source img for each card
  card1Src = "img/cardA.png";
  card2Src = "img/cardA.png";
  card3Src = "img/cardB.png";
  card4Src = "img/cardB.png";

  card5Src = "img/cardC.png";
  card6Src = "img/cardC.png";
  card7Src = "img/cardD.png";
  card8Src = "img/cardD.png";

  card9Src = "img/cardE.png";
  card10Src = "img/cardE.png";
  card11Src = "img/cardF.png";
  card12Src = "img/cardF.png";

  card13Src = "img/cardG.png";
  card14Src = "img/cardG.png";
  card15Src = "img/cardH.png";
  card16Src = "img/cardH.png";

  // 0 for not flipped; 1 for is flipped; 2 for matching pair found
  card1Flipped = 0;
  card2Flipped = 0;
  card3Flipped = 0;
  card4Flipped = 0;

  card5Flipped = 0;
  card6Flipped = 0;
  card7Flipped = 0;
  card8Flipped = 0;

  card9Flipped = 0;
  card10Flipped = 0;
  card11Flipped = 0;
  card12Flipped = 0;

  card13Flipped = 0;
  card14Flipped = 0;
  card15Flipped = 0;
  card16Flipped = 0;

  currentImagesFlipped = 0;

  // keep track of which cards are flipped
  firstFlippedCard = 0;
  secondFlippedCard = 0;

  score = 0;
  gameOver = false;

  display();
}

function flipCard(num) {
  /* keep two images flipped at most and
  turn over the others ones when a third is pressed
  unless the image has a match */
  if (currentImagesFlipped == 2) {
    if (card1Flipped != 2) card1Flipped = 0;
    if (card2Flipped != 2) card2Flipped = 0;
    if (card3Flipped != 2) card3Flipped = 0;
    if (card4Flipped != 2) card4Flipped = 0;
    if (card5Flipped != 2) card5Flipped = 0;
    if (card6Flipped != 2) card6Flipped = 0;
    if (card7Flipped != 2) card7Flipped = 0;
    if (card8Flipped != 2) card8Flipped = 0;
    if (card9Flipped != 2) card9Flipped = 0;
    if (card10Flipped != 2) card10Flipped = 0;
    if (card11Flipped != 2) card11Flipped = 0;
    if (card12Flipped != 2) card12Flipped = 0;
    if (card13Flipped != 2) card13Flipped = 0;
    if (card14Flipped != 2) card14Flipped = 0;
    if (card15Flipped != 2) card15Flipped = 0;
    if (card16Flipped != 2) card16Flipped = 0;

    currentImagesFlipped = 0;
    firstFlippedCard = 0;
    secondFlippedCard = 0;
  }

  var flippedAnImage = false;

  if (num == "1" && card1Flipped == 0) {
    card1Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "2" && card2Flipped == 0) {
    card2Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "3" && card3Flipped == 0) {
    card3Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "4" && card4Flipped == 0) {
    card4Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "5" && card5Flipped == 0) {
    card5Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "6" && card6Flipped == 0) {
    card6Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "7" && card7Flipped == 0) {
    card7Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "8" && card8Flipped == 0) {
    card8Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "9" && card9Flipped == 0) {
    card9Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "10" && card10Flipped == 0) {
    card10Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "11" && card11Flipped == 0) {
    card11Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "12" && card12Flipped == 0) {
    card12Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "13" && card13Flipped == 0) {
    card13Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "14" && card14Flipped == 0) {
    card14Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "15" && card15Flipped == 0) {
    card15Flipped = 1;
    flippedAnImage = true;
  }

  if (num == "16" && card16Flipped == 0) {
    card16Flipped = 1;
    flippedAnImage = true;
  }

  if (currentImagesFlipped == 0) firstFlippedCard = num;
  if (currentImagesFlipped == 1) secondFlippedCard = num;

  if (flippedAnImage) {
    score += 1;
    currentImagesFlipped += 1;
  }

  if (currentImagesFlipped == 2) checkCardMatches();

  display();
}

function checkCardMatches() {
  /* Check if the card sources are the same; if so, then they match */
  var firstFlippedCardSrc = "";
  var secondFlippedCardSrc = "";

  // assign the current flipped cards' sources to a local variable
  if (firstFlippedCard == 1) firstFlippedCardSrc = card1Src;
  if (firstFlippedCard == 2) firstFlippedCardSrc = card2Src;
  if (firstFlippedCard == 3) firstFlippedCardSrc = card3Src;
  if (firstFlippedCard == 4) firstFlippedCardSrc = card4Src;
  if (firstFlippedCard == 5) firstFlippedCardSrc = card5Src;
  if (firstFlippedCard == 6) firstFlippedCardSrc = card6Src;
  if (firstFlippedCard == 7) firstFlippedCardSrc = card7Src;
  if (firstFlippedCard == 8) firstFlippedCardSrc = card8Src;
  if (firstFlippedCard == 9) firstFlippedCardSrc = card9Src;
  if (firstFlippedCard == 10) firstFlippedCardSrc = card10Src;
  if (firstFlippedCard == 11) firstFlippedCardSrc = card11Src;
  if (firstFlippedCard == 12) firstFlippedCardSrc = card12Src;
  if (firstFlippedCard == 13) firstFlippedCardSrc = card13Src;
  if (firstFlippedCard == 14) firstFlippedCardSrc = card14Src;
  if (firstFlippedCard == 15) firstFlippedCardSrc = card15Src;
  if (firstFlippedCard == 16) firstFlippedCardSrc = card16Src;

  if (secondFlippedCard == 1) secondFlippedCardSrc = card1Src;
  if (secondFlippedCard == 2) secondFlippedCardSrc = card2Src;
  if (secondFlippedCard == 3) secondFlippedCardSrc = card3Src;
  if (secondFlippedCard == 4) secondFlippedCardSrc = card4Src;
  if (secondFlippedCard == 5) secondFlippedCardSrc = card5Src;
  if (secondFlippedCard == 6) secondFlippedCardSrc = card6Src;
  if (secondFlippedCard == 7) secondFlippedCardSrc = card7Src;
  if (secondFlippedCard == 8) secondFlippedCardSrc = card8Src;
  if (secondFlippedCard == 9) secondFlippedCardSrc = card9Src;
  if (secondFlippedCard == 10) secondFlippedCardSrc = card10Src;
  if (secondFlippedCard == 11) secondFlippedCardSrc = card11Src;
  if (secondFlippedCard == 12) secondFlippedCardSrc = card12Src;
  if (secondFlippedCard == 13) secondFlippedCardSrc = card13Src;
  if (secondFlippedCard == 14) secondFlippedCardSrc = card14Src;
  if (secondFlippedCard == 15) secondFlippedCardSrc = card15Src;
  if (secondFlippedCard == 16) secondFlippedCardSrc = card16Src;

  // keep them flipped if the sources are the same
  if (firstFlippedCardSrc == secondFlippedCardSrc) {
    if (firstFlippedCard == 1) card1Flipped = 2;
    if (firstFlippedCard == 2) card2Flipped = 2;
    if (firstFlippedCard == 3) card3Flipped = 2;
    if (firstFlippedCard == 4) card4Flipped = 2;
    if (firstFlippedCard == 5) card5Flipped = 2;
    if (firstFlippedCard == 6) card6Flipped = 2;
    if (firstFlippedCard == 7) card7Flipped = 2;
    if (firstFlippedCard == 8) card8Flipped = 2;
    if (firstFlippedCard == 9) card9Flipped = 2;
    if (firstFlippedCard == 10) card10Flipped = 2;
    if (firstFlippedCard == 11) card11Flipped = 2;
    if (firstFlippedCard == 12) card12Flipped = 2;
    if (firstFlippedCard == 13) card13Flipped = 2;
    if (firstFlippedCard == 14) card14Flipped = 2;
    if (firstFlippedCard == 15) card15Flipped = 2;
    if (firstFlippedCard == 16) card16Flipped = 2;

    if (secondFlippedCard == 1) card1Flipped = 2;
    if (secondFlippedCard == 2) card2Flipped = 2;
    if (secondFlippedCard == 3) card3Flipped = 2;
    if (secondFlippedCard == 4) card4Flipped = 2;
    if (secondFlippedCard == 5) card5Flipped = 2;
    if (secondFlippedCard == 6) card6Flipped = 2;
    if (secondFlippedCard == 7) card7Flipped = 2;
    if (secondFlippedCard == 8) card8Flipped = 2;
    if (secondFlippedCard == 9) card9Flipped = 2;
    if (secondFlippedCard == 10) card10Flipped = 2;
    if (secondFlippedCard == 11) card11Flipped = 2;
    if (secondFlippedCard == 12) card12Flipped = 2;
    if (secondFlippedCard == 13) card13Flipped = 2;
    if (secondFlippedCard == 14) card14Flipped = 2;
    if (secondFlippedCard == 15) card15Flipped = 2;
    if (secondFlippedCard == 16) card16Flipped = 2;
  }

  // check if every card matches
  if (
    card1Flipped == 2 &&
    card2Flipped == 2 &&
    card3Flipped == 2 &&
    card4Flipped == 2 &&
    card5Flipped == 2 &&
    card6Flipped == 2 &&
    card7Flipped == 2 &&
    card8Flipped == 2 &&
    card9Flipped == 2 &&
    card10Flipped == 2 &&
    card11Flipped == 2 &&
    card12Flipped == 2 &&
    card13Flipped == 2 &&
    card14Flipped == 2 &&
    card15Flipped == 2 &&
    card16Flipped == 2
  ) {
    gameOver = true;
  }

  display();
}

function reset() {
  card1Flipped = 0;
  card2Flipped = 0;
  card3Flipped = 0;
  card4Flipped = 0;

  card5Flipped = 0;
  card6Flipped = 0;
  card7Flipped = 0;
  card8Flipped = 0;

  card9Flipped = 0;
  card10Flipped = 0;
  card11Flipped = 0;
  card12Flipped = 0;

  card13Flipped = 0;
  card14Flipped = 0;
  card15Flipped = 0;
  card16Flipped = 0;

  currentImagesFlipped = 0;
  score = 0;
  gameOver = false;

  messages.innerHTML = "";

  display();
}

function display() {
  if (card1Flipped == 1 || card1Flipped == 2) {
    card1.src = card1Src;
  } else {
    card1.src = cardBackSrc;
  }

  if (card2Flipped == 1 || card2Flipped == 2) {
    card2.src = card2Src;
  } else {
    card2.src = cardBackSrc;
  }

  if (card3Flipped == 1 || card3Flipped == 2) {
    card3.src = card3Src;
  } else {
    card3.src = cardBackSrc;
  }

  if (card4Flipped == 1 || card4Flipped == 2) {
    card4.src = card4Src;
  } else {
    card4.src = cardBackSrc;
  }

  if (card5Flipped == 1 || card5Flipped == 2) {
    card5.src = card5Src;
  } else {
    card5.src = cardBackSrc;
  }

  if (card6Flipped == 1 || card6Flipped == 2) {
    card6.src = card6Src;
  } else {
    card6.src = cardBackSrc;
  }

  if (card7Flipped == 1 || card7Flipped == 2) {
    card7.src = card7Src;
  } else {
    card7.src = cardBackSrc;
  }

  if (card8Flipped == 1 || card8Flipped == 2) {
    card8.src = card8Src;
  } else {
    card8.src = cardBackSrc;
  }

  if (card9Flipped == 1 || card9Flipped == 2) {
    card9.src = card9Src;
  } else {
    card9.src = cardBackSrc;
  }

  if (card10Flipped == 1 || card10Flipped == 2) {
    card10.src = card10Src;
  } else {
    card10.src = cardBackSrc;
  }

  if (card11Flipped == 1 || card11Flipped == 2) {
    card11.src = card11Src;
  } else {
    card11.src = cardBackSrc;
  }

  if (card12Flipped == 1 || card12Flipped == 2) {
    card12.src = card12Src;
  } else {
    card12.src = cardBackSrc;
  }

  if (card13Flipped == 1 || card13Flipped == 2) {
    card13.src = card13Src;
  } else {
    card13.src = cardBackSrc;
  }

  if (card14Flipped == 1 || card14Flipped == 2) {
    card14.src = card14Src;
  } else {
    card14.src = cardBackSrc;
  }

  if (card15Flipped == 1 || card15Flipped == 2) {
    card15.src = card15Src;
  } else {
    card15.src = cardBackSrc;
  }

  if (card16Flipped == 1 || card16Flipped == 2) {
    card16.src = card16Src;
  } else {
    card16.src = cardBackSrc;
  }

  scoreDisplay.innerHTML = score;

  if (gameOver) {
    messages.innerHTML = "You win!";
  }
}
