function initialize() {
  console.log("fun initialize");
  playerHandDisplay = document.getElementById("bottom");
  rockDisplayCount = document.getElementById("rockDisplay");
  paperDisplayCount = document.getElementById("paperDisplay");
  scissorsDisplayCount = document.getElementById("scissorsDisplay");
  message = document.getElementById("message");
  log = document.getElementById("log");

  rockImage = document.getElementById("rock");
  paperImage = document.getElementById("paper");
  scissorsImage = document.getElementById("scissors");

  playerRock = 5;
  playerPaper = 5;
  playerScissors = 5;

  computerRock = 5;
  computerPaper = 5;
  computerScissors = 5;

  currentClickedCard = "";

  // variables to check if player plays three cards in a row
  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  currentMessageToLog = "";

  display();
}

function selectCard(card) {
  console.log("fun selectCard");
  currentClickedCard = card;
  display();
}

function breakCard(playerToBreak) {
  if (playerToBreak == "player") {
    if (lastPlayerCard == "rock") playerRock = 0;
    if (lastPlayerCard == "paper") playerPaper = 0;
    if (lastPlayerCard == "scissors") playerScissors = 0;
  }

  if (playerToBreak == "computer") {
    if (lastComputerCard == "rock") computerRock = 0;
    if (lastComputerCard == "paper") computerPaper = 0;
    if (lastComputerCard == "scissors") computerScissors = 0;
  }
}

function commitPlay() {
  console.log("fun commitPlay");
  if (currentClickedCard == "") {
    message.innerHTML = "Pick a card!";
  } else {

    // increment the timesInRow variable for player by 1 if the last card is the same as the current card
    if (lastPlayerCard == currentClickedCard) timesInRowPlayer++;
    else timesInRowPlayer = 1;


    if (timesInRowPlayer == 3) {
      breakCard("player");
    } else {
      var currentComputerCard = computerPicksCard();

      // increment the timesInRow variable for computer by 1 if the last card is the same as the current card
      if (lastComputerCard == currentComputerCard) timesInRowComputer++;
      else timesInRowComputer = 1;

      if (timesInRowComputer == 3) breakCard("computer");
      else evaluateMove(currentClickedCard, currentComputerCard);

      lastComputerCard = currentComputerCard;
      lastPlayerCard = currentClickedCard;
      currentClickedCard = "";
    }
  }

  display();
}

function computerPicksCard() {
  console.log("fun computerPicksCard");

  var randNum = Math.floor(Math.random() * 3 + 1);
  var cardToPlay;
  if (randNum == 1) cardToPlay = "rock";
  if (randNum == 2) cardToPlay = "paper";
  if (randNum == 3) cardToPlay = "scissors";

  return cardToPlay;
}

function evaluateMove(playerCard, computerCard) {
  console.log("fun evalutateMove");

  if (playerCard == "rock") {
    if (computerCard == "rock") {
      // tie
    } else if (computerCard == "paper") {
      // lose
      playerPaper--;
      computerPaper++;
    } else {
      // win
      playerScissors++;
      computerScissors--;
    }
  } else if (playerCard == "paper") {
    if (computerCard == "rock") {
      // win
      playerRock++;
      computerRock--;
    } else if (computerCard == "paper") {
      // tie

    } else {
      // lose
      playerPaper--;
      computerPaper++;
    }
  } else if (playerCard == "scissors") {
    if (computerCard == "rock") {
      // lose
      playerScissors--;
      computerScissors++;
    } else if (computerCard == "paper") {
      // win
      playerPaper++;
      computerPaper--;
    } else {
      // tie
    }
  }

  logLastMove(lastPlayerCard, lastComputerCard)
  currentClickedCard = "";
  display();
}

function logLastMove(playerCard, computerCard) {
  currentMessageToLog = `player: ${playerCard}, computer: ${computerCard}`
}

function display() {
  rockDisplayCount.innerHTML = playerRock;
  paperDisplayCount.innerHTML = playerPaper;
  scissorsDisplayCount.innerHTML = playerScissors;
  message.innerHTML = currentClickedCard.toUpperCase();
  log.innerHTML = currentMessageToLog;

  // highlight the current clicked card
  if (currentClickedCard == "rock") {
    rockImage.style.border = "medium solid #FF0F1F";
    paperImage.style.border = "";
    scissorsImage.style.border = "";
  } else if (currentClickedCard == "paper") {
    paperImage.style.border = "medium solid #FF0F1F";
    rockImage.style.border = "";
    scissorsImage.style.border = "";
  } else if (currentClickedCard == "scissors") {
    scissorsImage.style.border = "medium solid #FF0F1F";
    rockImage.style.border = "";
    paperImage.style.border = "";
  } else {
    rockImage.style.border = "";
    paperImage.style.border = "";
    scissorsImage.style.border = "";
  }
}
