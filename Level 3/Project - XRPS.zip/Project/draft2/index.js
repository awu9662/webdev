function initialize() {
  console.log("fun initialize");
  playerHandDisplay = document.getElementById("bottom");
  rockDisplayCount = document.getElementById("rockDisplay");
  paperDisplayCount = document.getElementById("paperDisplay");
  scissorsDisplayCount = document.getElementById("scissorsDisplay");
  message = document.getElementById("message");
  logTable = document.getElementById("log");

  rockImage = document.getElementById("rock");
  paperImage = document.getElementById("paper");
  scissorsImage = document.getElementById("scissors");

  playerRock = 5;
  playerPaper = 5;
  playerScissors = 5;

  computerRock = 5;
  computerPaper = 5;
  computerScissors = 5;

  currentClickedCard = "";
  currentComputerCard = "";

  // variables to check if player plays three cards in a row
  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  winnerOfGame = "";

  display();
}

function selectCard(card) {
  console.log("fun selectCard");
  var allowClick = false;

  // prevent clicking if the game is over
  if (winnerOfGame == "player") {
    message.innerHTML = "You won already!";
  } else if (winnerOfGame == "computer") {
    message.innerHTML = "Give up! You lost!";
  } else {
    if (card == "rock" && playerRock > 0) allowClick = true;
    if (card == "paper" && playerPaper > 0) allowClick = true;
    if (card == "scissors" && playerScissors > 0) allowClick = true;
    if (allowClick) currentClickedCard = card;
  }
  display();
}

function breakCard(playerToBreak) {
  console.log("fun BREAKCARD");
  if (playerToBreak == "player") {
    if (lastPlayerCard == "rock") playerRock = 0;
    if (lastPlayerCard == "paper") playerPaper = 0;
    if (lastPlayerCard == "scissors") playerScissors = 0;
  }

  if (playerToBreak == "computer") {
    if (lastComputerCard == "rock") computerRock = 0;
    if (lastComputerCard == "paper") computerPaper = 0;
    if (lastComputerCard == "scissors") computerScissors = 0;
  }

  logBrokenCard(playerToBreak);

  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  currentClickedCard = "";
}

function commitPlay() {
  console.log("fun commitPlay");
  if (currentClickedCard == "") {
    message.innerHTML = "Pick a card!";
  } else {
    // increment the timesInRow variable for player by 1 if the last card is the same as the current card
    if (lastPlayerCard == currentClickedCard) timesInRowPlayer++;
    else timesInRowPlayer = 1;

    if (timesInRowPlayer == 3) {
      breakCard("player");
    } else {
      currentComputerCard = computerPicksCard();

      // increment the timesInRow variable for computer by 1 if the last card is the same as the current card
      if (lastComputerCard == currentComputerCard) timesInRowComputer++;
      else timesInRowComputer = 1;

      if (timesInRowComputer == 3) breakCard("computer");
      else evaluateMove(currentClickedCard, currentComputerCard);

      lastPlayerCard = currentClickedCard;
      lastComputerCard = currentComputerCard;
      currentClickedCard = "";
      currentComputerCard = "";
    }
  }

  determineWinner();
  display();
}

function computerPicksCard() {
  console.log("fun computerPicksCard");
  var cardToPlay;
  var possiblePlay = false;

  while (!possiblePlay) {
    if (computerRock + computerPaper + computerScissors == 0) break;

    var randNum = Math.floor(Math.random() * 3 + 1);

    if (randNum == 1 && computerRock > 0) {
      cardToPlay = "rock";
      possiblePlay = true;
    }
    if (randNum == 2 && computerPaper > 0) {
      cardToPlay = "paper";
      possiblePlay = true;
    }
    if (randNum == 3 && computerScissors > 0) {
      cardToPlay = "scissors";
      possiblePlay = true;
    }
  }

  return cardToPlay;
}

function evaluateMove(playerCard, computerCard) {
  console.log("fun evalutateMove");
  var lastRoundStatus = "tie";

  if (playerCard == "rock") {
    if (computerCard == "rock") {
      // tie
    } else if (computerCard == "paper") {
      // lose
      playerRock--;
      computerRock++;
      lastRoundStatus = "lost";
    } else {
      // win
      playerScissors++;
      computerScissors--;
      lastRoundStatus = "win";
    }
  } else if (playerCard == "paper") {
    if (computerCard == "rock") {
      // win
      playerRock++;
      computerRock--;
      lastRoundStatus = "win";
    } else if (computerCard == "paper") {
      // tie
    } else {
      // lose
      playerPaper--;
      computerPaper++;
      lastRoundStatus = "lost";
    }
  } else if (playerCard == "scissors") {
    if (computerCard == "rock") {
      // lose
      playerScissors--;
      computerScissors++;
      lastRoundStatus = "lost";
    } else if (computerCard == "paper") {
      // win
      playerPaper++;
      computerPaper--;
      lastRoundStatus = "win";
    } else {
      // tie
    }
  }

  logLastMove(playerCard, computerCard, lastRoundStatus);

  display();
}

function logLastMove(playerCard, computerCard, lastRoundStatus) {
  /* add images to the table to show which person won the last round */
  newTr = logTable.insertRow();

  var playerCardToInsert;
  var computerCardToInsert;
  if (playerCard == "rock") playerCardToInsert = "rock";
  else if (playerCard == "paper") playerCardToInsert = "paper";
  else if (playerCard == "scissors") playerCardToInsert = "scissors";

  if (computerCard == "rock") computerCardToInsert = "rock";
  else if (computerCard == "paper") computerCardToInsert = "paper";
  else if (computerCard == "scissors") computerCardToInsert = "scissors";

  // insert appropriate image
  newCell = newTr.insertCell();
  cardImage = document.createElement("img");
  cardImage.src = "img/" + playerCardToInsert + ".png";
  newCell.appendChild(cardImage);

  newCell = newTr.insertCell();
  newCell.innerHTML = lastRoundStatus;

  newCell = newTr.insertCell();
  cardImage = document.createElement("img");
  cardImage.src = "img/" + computerCardToInsert + ".png";
  newCell.appendChild(cardImage);
}

function logBrokenCard(playerToBreak) {
  var newTr = logTable.insertRow();
  newCell = newTr.insertCell();

  if (playerToBreak == "player") newCell.innerHTML = "You have broken your " + lastPlayerCard + "s.";
  else newCell.innerHTML = "The computer has broken its " + lastComputerCard + ".";
}

function determineWinner() {
  if (playerRock + playerPaper + playerScissors == 0) {
    message.innerHTML = "You lose";
    winnerOfGame = "computer";
  } else if (computerRock + computerPaper + computerScissors == 0) {
    message.innerHTML = "You win";
    winnerOfGame = "player";
  }
}

function display() {
  rockDisplayCount.innerHTML = playerRock;
  paperDisplayCount.innerHTML = playerPaper;
  scissorsDisplayCount.innerHTML = playerScissors;
  if (currentClickedCard != "") message.innerHTML = "";

  // highlight the current clicked card
  if (currentClickedCard == "rock") {
    rockImage.style.border = "medium solid #FF0F1F";
    paperImage.style.border = "";
    scissorsImage.style.border = "";
  } else if (currentClickedCard == "paper") {
    paperImage.style.border = "medium solid #FF0F1F";
    rockImage.style.border = "";
    scissorsImage.style.border = "";
  } else if (currentClickedCard == "scissors") {
    scissorsImage.style.border = "medium solid #FF0F1F";
    rockImage.style.border = "";
    paperImage.style.border = "";
  } else {
    rockImage.style.border = "";
    paperImage.style.border = "";
    scissorsImage.style.border = "";
  }
  // console.log(`Rock: ${computerRock}\nPaper: ${computerPaper}\nScissors: ${computerScissors}`);
}
