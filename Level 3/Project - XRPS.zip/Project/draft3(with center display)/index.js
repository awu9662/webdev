function initialize() {
  console.log("fun initialize");

  rockDisplayCount = document.getElementById("rockDisplay");
  paperDisplayCount = document.getElementById("paperDisplay");
  scissorsDisplayCount = document.getElementById("scissorsDisplay");

  computerRockDisplayCount = document.getElementById("computerRockDisplay");
  computerPaperDisplayCount = document.getElementById("computerPaperDisplay");
  computerScissorsDisplayCount = document.getElementById("computerScissorsDisplay");

  message = document.getElementById("message");
  logTable = document.getElementById("log");

  playerCardToDisplay = document.getElementById("playerCardToDisplay");
  computerCardToDisplay = document.getElementById("computerCardToDisplay");
  roundStatusDisplay = document.getElementById("roundStatusDisplay");

  playerRock = 5;
  playerPaper = 5;
  playerScissors = 5;

  computerRock = 5;
  computerPaper = 5;
  computerScissors = 5;

  currentClickedCard = "";
  currentComputerCard = "";

  lastRoundStatus = "";

  cardBroken = false;

  // variables to check if player plays three cards in a row
  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  winnerOfGame = "";

  numMoves = 0;

  display();
}

function selectCard(card) {
  console.log("fun selectCard");
  var allowClick = false;

  // prevent clicking if the game is over
  if (winnerOfGame == "player") {
    message.innerHTML = "You won already!";
  } else if (winnerOfGame == "computer") {
    message.innerHTML = "Give up! You lost!";
  } else {
    if (card == "rock" && playerRock > 0) allowClick = true;
    if (card == "paper" && playerPaper > 0) allowClick = true;
    if (card == "scissors" && playerScissors > 0) allowClick = true;
    if (allowClick) currentClickedCard = card;
    makePlay();
  }

  display();
}

function makePlay() {
  console.log("fun makePlay");
  cardBroken = false;

  if (currentClickedCard == "") {
    message.innerHTML = "Pick a valid card!";
  } else {
    numMoves++;

    // increment the timesInRow variable for player by 1 if the last card is the same as the current card
    if (lastPlayerCard == currentClickedCard) timesInRowPlayer++;
    else timesInRowPlayer = 1;

    if (timesInRowPlayer == 3) {
      breakCard("player");
    } else {
      currentComputerCard = computerPicksCard();

      // increment the timesInRow variable for computer by 1 if the last card is the same as the current card
      if (lastComputerCard == currentComputerCard) timesInRowComputer++;
      else timesInRowComputer = 1;

      if (timesInRowComputer == 3) breakCard("computer");
      else evaluateMove(currentClickedCard, currentComputerCard);

      lastPlayerCard = currentClickedCard;
      lastComputerCard = currentComputerCard;
      currentClickedCard = "";
      currentComputerCard = "";
    }
  }

  determineWinner();
  display();
}

function breakCard(playerToBreak) {
  console.log("fun BREAKCARD");

  // used to display the last round status
  cardBroken = true;

  if (playerToBreak == "player") {
    if (lastPlayerCard == "rock") playerRock = 0;
    if (lastPlayerCard == "paper") playerPaper = 0;
    if (lastPlayerCard == "scissors") playerScissors = 0;
  }

  if (playerToBreak == "computer") {
    if (lastComputerCard == "rock") computerRock = 0;
    if (lastComputerCard == "paper") computerPaper = 0;
    if (lastComputerCard == "scissors") computerScissors = 0;
  }

  logBrokenCard(playerToBreak);

  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  currentClickedCard = "";
  currentComputerCard = "";
}

function computerPicksCard() {
  console.log("fun computerPicksCard");
  var cardToPlay;
  var possiblePlay = false;

  while (!possiblePlay) {
    if (computerRock + computerPaper + computerScissors == 0) break;

    var randNum = Math.floor(Math.random() * 3 + 1);

    if (randNum == 1 && computerRock > 0) {
      cardToPlay = "rock";
      possiblePlay = true;
    }
    if (randNum == 2 && computerPaper > 0) {
      cardToPlay = "paper";
      possiblePlay = true;
    }
    if (randNum == 3 && computerScissors > 0) {
      cardToPlay = "scissors";
      possiblePlay = true;
    }
  }

  return cardToPlay;
}

function evaluateMove(playerCard, computerCard) {
  console.log("fun evalutateMove");
  lastRoundStatus = "tie";

  if (playerCard == "rock") {
    if (computerCard == "rock") {
      // tie
    } else if (computerCard == "paper") {
      // lose
      playerRock--;
      computerRock++;
      lastRoundStatus = "lost";
    } else {
      // win
      playerScissors++;
      computerScissors--;
      lastRoundStatus = "win";
    }
  } else if (playerCard == "paper") {
    if (computerCard == "rock") {
      // win
      playerRock++;
      computerRock--;
      lastRoundStatus = "win";
    } else if (computerCard == "paper") {
      // tie
    } else {
      // lose
      playerPaper--;
      computerPaper++;
      lastRoundStatus = "lost";
    }
  } else if (playerCard == "scissors") {
    if (computerCard == "rock") {
      // lose
      playerScissors--;
      computerScissors++;
      lastRoundStatus = "lost";
    } else if (computerCard == "paper") {
      // win
      playerPaper++;
      computerPaper--;
      lastRoundStatus = "win";
    } else {
      // tie
    }
  }

  logLastMove(playerCard, computerCard, lastRoundStatus);
}

function logLastMove(playerCard, computerCard, lastRoundStatus) {
  /* add images to the table to show which person won the last round */
  newTr = logTable.insertRow(0);

  newCell = newTr.insertCell();
  newCell.style.color = "green";
  newCell.innerHTML = numMoves;

  var playerCardToInsert;
  var computerCardToInsert;
  if (playerCard == "rock") playerCardToInsert = "rock";
  else if (playerCard == "paper") playerCardToInsert = "paper";
  else if (playerCard == "scissors") playerCardToInsert = "scissors";

  if (computerCard == "rock") computerCardToInsert = "rock";
  else if (computerCard == "paper") computerCardToInsert = "paper";
  else if (computerCard == "scissors") computerCardToInsert = "scissors";

  // insert appropriate image
  newCell = newTr.insertCell();
  cardImage = document.createElement("img");
  cardImage.src = "img/" + playerCardToInsert + ".png";
  newCell.appendChild(cardImage);

  newCell = newTr.insertCell();

  var color;

  if (lastRoundStatus == "win") color = "green";
  else if (lastRoundStatus == "lost") color = "red";
  else color = "black";
  newCell.style.color = color;
  newCell.innerHTML = lastRoundStatus.charAt(0).toUpperCase() + lastRoundStatus.slice(1);

  newCell = newTr.insertCell();
  cardImage = document.createElement("img");
  cardImage.src = "img/" + computerCardToInsert + ".png";
  newCell.appendChild(cardImage);
}

function logBrokenCard(playerToBreak) {
  var newTr = logTable.insertRow(0);
  newCell = newTr.insertCell();
  newCell.style.color = "green";
  newCell.innerHTML = numMoves;

  newCell = newTr.insertCell();
  newCell.colSpan = "3";

  // display the broken card in the center and add it to the table
  roundStatusDisplay.style.fontSize = "1.2em";
  roundStatusDisplay.style.color = "black";
  if (playerToBreak == "player") {
    var text = "You have broken your " + lastPlayerCard + ".";
    newCell.innerHTML = text;
    roundStatusDisplay.innerHTML = text;
  } else {
    var text = "The computer has broken its " + lastComputerCard + ".";
    newCell.innerHTML = text;
    roundStatusDisplay.innerHTML = text;
  }
}

function determineWinner() {
  if (playerRock + playerPaper + playerScissors == 0) {
    winnerOfGame = "computer";
  } else if (computerRock + computerPaper + computerScissors == 0) {
    winnerOfGame = "player";
  }
}

function display() {
  console.log("FUN display");
  rockDisplayCount.innerHTML = playerRock;
  paperDisplayCount.innerHTML = playerPaper;
  scissorsDisplayCount.innerHTML = playerScissors;

  computerRockDisplayCount.innerHTML = computerRock;
  computerPaperDisplayCount.innerHTML = computerPaper;
  computerScissorsDisplayCount.innerHTML = computerScissors;

  if (currentClickedCard != "") message.innerHTML = "";

  // enlarge last played cards
  if (lastPlayerCard == "rock") {
    playerCardToDisplay.innerHTML = "<img src='img/rock.png' />";
  } else if (lastPlayerCard == "paper") {
    playerCardToDisplay.innerHTML = "<img src='img/paper.png' />";
  } else if (lastPlayerCard == "scissors") {
    playerCardToDisplay.innerHTML = "<img src='img/scissors.png' />";
  } else {
    playerCardToDisplay.innerHTML = "";
  }

  if (lastComputerCard == "rock") {
    computerCardToDisplay.innerHTML = "<img src='img/rock.png' />";
  } else if (lastComputerCard == "paper") {
    computerCardToDisplay.innerHTML = "<img src='img/paper.png' />";
  } else if (lastComputerCard == "scissors") {
    computerCardToDisplay.innerHTML = "<img src='img/scissors.png' />";
  } else {
    computerCardToDisplay.innerHTML = "";
  }

  // show who won the last round
  if (!cardBroken) {
    roundStatusDisplay.style.fontSize = "1.2em";
    if (lastRoundStatus == "win") {
      roundStatusDisplay.style.color = "green";
      roundStatusDisplay.innerHTML = "Win";
    } else if (lastRoundStatus == "lost") {
      roundStatusDisplay.style.color = "red";
      roundStatusDisplay.innerHTML = "Lost";
    } else if (lastRoundStatus == "tie") {
      roundStatusDisplay.style.color = "black";
      roundStatusDisplay.innerHTML = "Tie";
    }
  }

  // big text to show winner
  if (winnerOfGame == "player") {
    playerCardToDisplay.style.fontSize = "4.5em";
    playerCardToDisplay.innerHTML = "You win!";
    computerCardToDisplay.innerHTML = "";
    roundStatusDisplay.innerHTML = "";
  } else if (winnerOfGame == "computer") {
    playerCardToDisplay.style.fontSize = "4.5em";
    playerCardToDisplay.innerHTML = "The computer wins!";
    computerCardToDisplay.innerHTML = "";
    roundStatusDisplay.innerHTML = "";
  }
}

function reset() {
  playerRock = 5;
  playerPaper = 5;
  playerScissors = 5;

  computerRock = 5;
  computerPaper = 5;
  computerScissors = 5;

  currentClickedCard = "";
  currentComputerCard = "";

  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  winnerOfGame = "";

  numMoves = 0;

  message.innerHTML = "";
  logTable.innerHTML = "";

  display();
}
