function initialize() {
  rockDisplayCount = document.getElementById("rockDisplay");
  paperDisplayCount = document.getElementById("paperDisplay");
  scissorsDisplayCount = document.getElementById("scissorsDisplay");

  computerRockDisplayCount = document.getElementById("computerRockDisplay");
  computerPaperDisplayCount = document.getElementById("computerPaperDisplay");
  computerScissorsDisplayCount = document.getElementById(
    "computerScissorsDisplay"
  );

  message = document.getElementById("message");
  logTable = document.getElementById("log");

  playerCardToDisplay = document.getElementById("playerCardToDisplay");
  computerCardToDisplay = document.getElementById("computerCardToDisplay");
  roundStatusDisplay = document.getElementById("roundStatusDisplay");

  // extra enchancements
  numCardsForm = document.getElementById("numCardsForm"); // custom number of starting cards

  playerRock = 5;
  playerPaper = 5;
  playerScissors = 5;

  computerRock = 5;
  computerPaper = 5;
  computerScissors = 5;

  currentClickedCard = "";
  currentComputerCard = "";

  lastRoundStatus = "";

  cardBroken = false;

  // variables to check if player plays three cards in a row
  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  winnerOfGame = "";

  numMoves = 0;

  /* extra variables */
  instructionToggle = true;

  // keep track of all the rounds in a list
  roundStatuses = [];

  // used to set a custom amount of starting cards
  newRockNumber = 5;
  newPaperNumber = 5;
  newScissorsNumber = 5;
  /* */

  display();
}

function selectCard(card) {
  var allowClick = false;

  // prevent clicking if the game is over
  if (winnerOfGame == "player") {
    message.innerHTML = "You won already!";
  } else if (winnerOfGame == "computer") {
    message.innerHTML = "Give up! You lost!";
  } else {
    if (card == "rock" && playerRock > 0) allowClick = true;
    if (card == "paper" && playerPaper > 0) allowClick = true;
    if (card == "scissors" && playerScissors > 0) allowClick = true;
    if (allowClick) currentClickedCard = card;
    makePlay();
  }

  display();
}

function makePlay() {
  cardBroken = false;

  if (currentClickedCard == "") {
    message.innerHTML = "Pick a valid card!";
  } else {
    message.innerHTML = "";
    numMoves++;

    // increment the timesInRow variable for player by 1 if the last card is the same as the current card
    if (lastPlayerCard == currentClickedCard) timesInRowPlayer++;
    else timesInRowPlayer = 1;

    if (timesInRowPlayer == 3) {
      breakCard("player");
    } else {
      currentComputerCard = computerPicksCard();

      // increment the timesInRow variable for computer by 1 if the last card is the same as the current card
      if (lastComputerCard == currentComputerCard) timesInRowComputer++;
      else timesInRowComputer = 1;

      if (timesInRowComputer == 3) breakCard("computer");
      else evaluateMove(currentClickedCard, currentComputerCard);

      lastPlayerCard = currentClickedCard;
      lastComputerCard = currentComputerCard;
      currentClickedCard = "";
      currentComputerCard = "";
    }
  }

  determineWinner();
  display();
}

function breakCard(playerToBreak) {
  // used to display the last round status
  cardBroken = true;

  if (playerToBreak == "player") {
    if (lastPlayerCard == "rock") playerRock = 0;
    if (lastPlayerCard == "paper") playerPaper = 0;
    if (lastPlayerCard == "scissors") playerScissors = 0;
  }

  if (playerToBreak == "computer") {
    if (lastComputerCard == "rock") computerRock = 0;
    if (lastComputerCard == "paper") computerPaper = 0;
    if (lastComputerCard == "scissors") computerScissors = 0;
  }

  logBrokenCard(playerToBreak);

  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  currentClickedCard = "";
  currentComputerCard = "";
}

function computerPicksCard() {
  var cardToPlay;
  var possiblePlay = false;

  while (!possiblePlay) {
    // stop the loop if computer has no cards
    if (computerRock + computerPaper + computerScissors == 0) break;

    var randNum = Math.floor(Math.random() * 3 + 1);

    if (randNum == 1 && computerRock > 0) {
      cardToPlay = "rock";
      possiblePlay = true;
    }
    if (randNum == 2 && computerPaper > 0) {
      cardToPlay = "paper";
      possiblePlay = true;
    }
    if (randNum == 3 && computerScissors > 0) {
      cardToPlay = "scissors";
      possiblePlay = true;
    }
  }

  return cardToPlay;
}

function evaluateMove(playerCard, computerCard) {
  lastRoundStatus = "tie";

  if (playerCard == "rock") {
    if (computerCard == "rock") {
      // tie
    } else if (computerCard == "paper") {
      // lose
      playerRock--;
      computerRock++;
      lastRoundStatus = "lost";
    } else {
      // win
      playerScissors++;
      computerScissors--;
      lastRoundStatus = "win";
    }
  } else if (playerCard == "paper") {
    if (computerCard == "rock") {
      // win
      playerRock++;
      computerRock--;
      lastRoundStatus = "win";
    } else if (computerCard == "paper") {
      // tie
    } else {
      // lose
      playerPaper--;
      computerPaper++;
      lastRoundStatus = "lost";
    }
  } else if (playerCard == "scissors") {
    if (computerCard == "rock") {
      // lose
      playerScissors--;
      computerScissors++;
      lastRoundStatus = "lost";
    } else if (computerCard == "paper") {
      // win
      playerPaper++;
      computerPaper--;
      lastRoundStatus = "win";
    } else {
      // tie
    }
  }

  roundStatuses.push(lastRoundStatus);

  logLastMove(playerCard, computerCard, lastRoundStatus);
  checkTies();
}

function checkTies() {
  // remove a card at random from both players if there is a tie three rounds in a row
  if (
    roundStatuses[roundStatuses.length - 1] == "tie" &&
    roundStatuses[roundStatuses.length - 2] == "tie" &&
    roundStatuses[roundStatuses.length - 3] == "tie"
  ) {
    var playerCardRemoved = false;
    var playerCardToRemove = "";
    while (!playerCardRemoved) {
      randNum = Math.floor(Math.random() * 3 + 1);
      if (randNum == 1 && playerRock > 0) {
        playerCardToRemove = "rock";
        playerCardRemoved = true;
      }
      if (randNum == 2 && playerPaper > 0) {
        playerCardToRemove = "paper";
        playerCardRemoved = true;
      }
      if (randNum == 3 && playerScissors > 0) {
        playerCardToRemove = "scissors";
        playerCardRemoved = true;
      }
    }

    var computerCardRemoved = false;
    var computerCardToRemove = "";
    while (!computerCardRemoved) {
      randNum = Math.floor(Math.random() * 3 + 1);
      if (randNum == 1 && computerRock > 0) {
        computerCardToRemove = "rock";
        computerCardRemoved = true;
      }
      if (randNum == 2 && computerPaper > 0) {
        computerCardToRemove = "paper";
        computerCardRemoved = true;
      }
      if (randNum == 3 && computerScissors > 0) {
        computerCardToRemove = "scissors";
        computerCardRemoved = true;
      }
    }

    if (playerCardToRemove == "rock") playerRock--;
    else if (playerCardToRemove == "paper") playerPaper--;
    else if (playerCardToRemove == "scissors") playerScissors--;

    if (computerCardToRemove == "rock") computerRock--;
    else if (computerCardToRemove == "paper") computerPaper--;
    else if (computerCardToRemove == "scissors") computerScissors--;

    logTie();
  }
}

function logLastMove(playerCard, computerCard, lastRoundStatus) {
  /* add images to the table to show which person won the last round */
  newTr = logTable.insertRow(0);

  newCell = newTr.insertCell();
  newCell.style.color = "green";
  newCell.innerHTML = numMoves.toString() + ". ";

  var playerCardToInsert;
  var computerCardToInsert;
  if (playerCard == "rock") playerCardToInsert = "rock";
  else if (playerCard == "paper") playerCardToInsert = "paper";
  else if (playerCard == "scissors") playerCardToInsert = "scissors";

  if (computerCard == "rock") computerCardToInsert = "rock";
  else if (computerCard == "paper") computerCardToInsert = "paper";
  else if (computerCard == "scissors") computerCardToInsert = "scissors";

  // insert appropriate image
  newCell = newTr.insertCell();
  cardImage = document.createElement("img");
  cardImage.src = "img/" + playerCardToInsert + ".png";
  newCell.appendChild(cardImage);

  newCell = newTr.insertCell();

  var color;
  if (lastRoundStatus == "win") color = "green";
  else if (lastRoundStatus == "lost") color = "red";
  else color = "black";
  newCell.style.color = color;
  newCell.innerHTML = lastRoundStatus.charAt(0).toUpperCase() + lastRoundStatus.slice(1); // capitalize

  newCell = newTr.insertCell();
  cardImage = document.createElement("img");
  cardImage.src = "img/" + computerCardToInsert + ".png";
  newCell.appendChild(cardImage);
}

function logBrokenCard(playerToBreak) {
  var newTr = logTable.insertRow(0);
  newCell = newTr.insertCell();
  newCell.style.color = "green";
  newCell.innerHTML = numMoves.toString() + ". ";

  newCell = newTr.insertCell();
  newCell.colSpan = "3";

  // display the broken card in the center and add it to the table
  roundStatusDisplay.style.fontSize = "1.2em";
  roundStatusDisplay.style.color = "black";
  if (playerToBreak == "player") {
    var text = "You have broken your " + lastPlayerCard + ".";
    newCell.innerHTML = text;
    roundStatusDisplay.innerHTML = text;
  } else {
    var text = "The computer has broken its " + lastComputerCard + ".";
    newCell.innerHTML = text;
    roundStatusDisplay.innerHTML = text;
  }
}

function logTie() {
  var newTr = logTable.insertRow(0);
  newCell = newTr.insertCell();
  newCell.style.color = "green";
  newCell.innerHTML = numMoves.toString() + ". ";

  newCell = newTr.insertCell();
  newCell.colSpan = "3";

  // display the broken card in the center and add it to the table
  roundStatusDisplay.style.fontSize = "1.2em";
  roundStatusDisplay.style.color = "black";
  var text = "Three consecutive ties = 1 card removed from each hand";
  newCell.innerHTML = text;
  roundStatusDisplay.innerHTML = text;
}

function determineWinner() {
  // determine if a player only has one type of card
  var playerWithOnlyOneTypeOfCard = "";
  if (playerRock > 0 && playerPaper == 0 && playerScissors == 0) {
    playerWithOnlyOneTypeOfCard = "player";
  } else if (playerRock == 0 && playerPaper > 0 && playerScissors == 0) {
    playerWithOnlyOneTypeOfCard = "player";
  } else if (playerRock == 0 && playerPaper == 0 && playerScissors > 0) {
    playerWithOnlyOneTypeOfCard = "player";
  }

  if (computerRock > 0 && computerPaper == 0 && computerScissors == 0) {
    playerWithOnlyOneTypeOfCard = "computer";
  } else if (computerRock == 0 && computerPaper > 0 && computerScissors == 0) {
    playerWithOnlyOneTypeOfCard = "computer";
  } else if (computerRock == 0 && computerPaper == 0 && computerScissors > 0) {
    playerWithOnlyOneTypeOfCard = "computer";
  }

  if (playerWithOnlyOneTypeOfCard == "player") {
    computerRock += playerRock;
    computerPaper += playerPaper;
    computerScissors += playerScissors;

    playerRock = 0;
    playerPaper = 0;
    playerScissors = 0;

    logLostCause("player");
  } else if (playerWithOnlyOneTypeOfCard == "computer") {
    playerRock += computerRock;
    playerPaper += computerPaper;
    playerScissors += computerScissors;

    computerRock = 0;
    computerPaper = 0;
    computerScissors = 0;

    logLostCause("computer");
  }

  if (playerRock + playerPaper + playerScissors == 0) {
    winnerOfGame = "computer";
  } else if (computerRock + computerPaper + computerScissors == 0) {
    winnerOfGame = "player";
  }
}

function logLostCause(playerToLog) {
  var newTr = logTable.insertRow(0);

  newCell = newTr.insertCell();
  newCell.colSpan = "4";
  newCell.style.color = "#f58442";

  // display the broken card in the center and add it to the table
  roundStatusDisplay.style.fontSize = "1.2em";
  roundStatusDisplay.style.color = "black";
  var text = "";
  if (playerToLog == "player") {
    text = "You are a lost cause.";
  } else if (playerToLog == "computer") {
    text = "The computer is a lost cause.";
  }
  newCell.innerHTML = text;
  roundStatusDisplay.innerHTML = text;

  lostCauseDisplay = document.getElementById("lostCause");
  lostCauseDisplay.style.margin = "1%";
  lostCauseDisplay.style.fontSize = "2em";
  lostCauseDisplay.style.color = "#f58442";

  if (playerToLog == "player") {
    lostCauseDisplay.innerHTML = "You only have one type of card left. <br>" + text;
  } else if (playerToLog == "computer") {
    lostCauseDisplay.innerHTML = "The computer only has one type of card left. <br>" + text;
  }
}

function display() {
  rockDisplayCount.innerHTML = playerRock;
  paperDisplayCount.innerHTML = playerPaper;
  scissorsDisplayCount.innerHTML = playerScissors;

  computerRockDisplayCount.innerHTML = computerRock;
  computerPaperDisplayCount.innerHTML = computerPaper;
  computerScissorsDisplayCount.innerHTML = computerScissors;

  if (currentClickedCard != "") message.innerHTML = "";

  // enlarge last played cards
  if (lastPlayerCard == "rock") {
    playerCardToDisplay.innerHTML = "<img src='img/rock.png' />";
  } else if (lastPlayerCard == "paper") {
    playerCardToDisplay.innerHTML = "<img src='img/paper.png' />";
  } else if (lastPlayerCard == "scissors") {
    playerCardToDisplay.innerHTML = "<img src='img/scissors.png' />";
  } else {
    playerCardToDisplay.innerHTML = "";
  }

  if (lastComputerCard == "rock") {
    computerCardToDisplay.innerHTML = "<img src='img/rock.png' />";
  } else if (lastComputerCard == "paper") {
    computerCardToDisplay.innerHTML = "<img src='img/paper.png' />";
  } else if (lastComputerCard == "scissors") {
    computerCardToDisplay.innerHTML = "<img src='img/scissors.png' />";
  } else {
    computerCardToDisplay.innerHTML = "";
  }

  // show who won the last round, unless a card is broken
  if (!cardBroken) {
    roundStatusDisplay.style.fontSize = "1.2em";
    if (lastRoundStatus == "win") {
      roundStatusDisplay.style.color = "green";
      roundStatusDisplay.innerHTML = "Win";
    } else if (lastRoundStatus == "lost") {
      roundStatusDisplay.style.color = "red";
      roundStatusDisplay.innerHTML = "Lost";
    } else if (lastRoundStatus == "tie") {
      roundStatusDisplay.style.color = "black";
      roundStatusDisplay.innerHTML = "Tie";
    }
  }

  // big text to show winner
  if (winnerOfGame == "player") {
    playerCardToDisplay.style.fontSize = "4.5em";
    playerCardToDisplay.innerHTML = "You win!";
    computerCardToDisplay.innerHTML = "";
    roundStatusDisplay.innerHTML = "";
  } else if (winnerOfGame == "computer") {
    playerCardToDisplay.style.fontSize = "4.5em";
    playerCardToDisplay.innerHTML = "The computer wins!";
    computerCardToDisplay.innerHTML = "";
    roundStatusDisplay.innerHTML = "";
  }
}

function reset() {
  playerRock = newRockNumber > 0 ? newRockNumber : 5;
  playerPaper = newPaperNumber > 0 ? newPaperNumber : 5;
  playerScissors = newScissorsNumber > 0 ? newScissorsNumber : 5;

  // computer has same number as player
  computerRock = playerRock;
  computerPaper = playerPaper;
  computerScissors = playerScissors;

  currentClickedCard = "";
  currentComputerCard = "";

  lastRoundStatus = "";
  cardBroken = false;

  lastPlayerCard = "";
  timesInRowPlayer = 1;
  lastComputerCard = "";
  timesInRowComputer = 1;

  winnerOfGame = "";

  numMoves = 0;

  message.innerHTML = "";
  logTable.innerHTML = "";
  roundStatusDisplay.innerHTML = "";

  document.getElementById("lostCause").innerHTML = "";

  display();
}

function displayInstructions() {
  instructions = document.getElementById("instructionText");
  instructionButton = document.getElementById("instructionButton");
  afterInstruction = document.getElementById("afterInstruction");

  instructionToggle = !instructionToggle;

  if (instructionToggle) {
    instructions.style.display = "inline";
    afterInstruction.innerHTML = "";
    instructionButton.innerHTML = "I know the rules";
  } else {
    instructions.style.display = "none";
    h2 = document.createElement("h2");
    h2.innerHTML = "Get playing!";
    afterInstruction.appendChild(h2);
    instructionButton.innerHTML = "Let me see the rules again";
  }
}

function readNumCardsForm() {
  newRockNumber = parseInt(numCardsForm.nRock.value);
  newPaperNumber = parseInt(numCardsForm.nPaper.value);
  newScissorsNumber = parseInt(numCardsForm.nScissors.value);

  // reset the inputs
  numCardsForm.nRock.value = "5";
  numCardsForm.nPaper.value = "5";
  numCardsForm.nScissors.value = "5";

  // reset the game and use the new values when person sumbits
  reset();
}
