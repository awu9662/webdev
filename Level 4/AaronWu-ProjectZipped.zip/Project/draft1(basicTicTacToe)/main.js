/* basic tic tac toe */

function initialize() {
  gameContainer = document.getElementById("gameContainer");
  startScreenDisplay = document.getElementById("startScreen");
  messages = document.getElementById("messages");

  firstLayerBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0];

  // player will choose if they want to be X or O
  playerSymbol = "";
  computerSymbol = "";

  isPlayersTurn = false;
  gameOver = false;

  display();
}

function initializePlayer(sym) {
  playerSymbol = sym;

  // X always goes first
  if (playerSymbol == "x") {
    isPlayersTurn = true;
    computerSymbol = "o";
  } else {
    isPlayersTurn = false;
    computerSymbol = "x";
    computerMakesMove();
  }

  display();
}

function makeMove(pos) {
  if (gameOver) return;
  if (!isPlayersTurn) return;

  if (firstLayerBoard[pos] == 0) {
    firstLayerBoard[pos] = playerSymbol;
    checkGameOver();
    computerMakesMove();
  }

  display();
}

function computerMakesMove() {
  if (gameOver) return;
  var legalMove = false;
  var i = 0;

  while (!legalMove) {
    var randomPos = Math.floor(Math.random() * 9);

    /* the move is allowed if the firstLayer is untaken */
    if (firstLayerBoard[randomPos] == 0) {
      legalMove = true;
      firstLayerBoard[randomPos] = computerSymbol;
    }

    i++;
    if (i > 100) {
      console.log("too many loops");
      break;
    }
  }

  checkGameOver();
  isPlayersTurn = true;

  display();
}

function checkGameOver() {
  // function will return true if the list has the same items at index a, b, and c
  function helper(list, a, b, c) {
    if (list[a] == list[b] && list[b] == list[c]) {
      if (list[a] != 0 && list[b] != 0 && list[c] != 0) {
        return true;
      }
    } else {
      return false;
    }
  }

  if (helper(firstLayerBoard, 0, 1, 2) || helper(firstLayerBoard, 0, 3, 6)) {
    endGame(firstLayerBoard[0]);
  }

  if (helper(firstLayerBoard, 2, 5, 8) || helper(firstLayerBoard, 6, 7, 8)) {
    endGame(firstLayerBoard[8]);
  }

  if (helper(firstLayerBoard, 1, 4, 7) || helper(firstLayerBoard, 3, 4, 5)) {
    endGame(firstLayerBoard[4]);
  }

  if (helper(firstLayerBoard, 0, 4, 8) || helper(firstLayerBoard, 2, 4, 6)) {
    endGame(firstLayerBoard[4]);
  }
}

function endGame(winner) {
  gameOver = true;
  if (playerSymbol == winner) {
    messages.innerHTML = "You win!"
  } else {
    messages.innerHTML = "You lose!"
  }
}

function display() {
  // start the game if player has chosen their symbol
  if (playerSymbol != "") {
    startScreenDisplay.style.display = "none";
    gameContainer.style.display = "block";
  } else {
    startScreenDisplay.style.display = "block";
    gameContainer.style.display = "none";
  }

  for (var i = 0; i < firstLayerBoard.length; i++) {
    var currentPos = document.getElementById("position" + i);

    if (firstLayerBoard[i] == 0) currentPos.innerHTML = "";
    else if (firstLayerBoard[i] == "x") currentPos.innerHTML = "X";
    else if (firstLayerBoard[i] == "o") currentPos.innerHTML = "O";
  }

}

function reset() {
  firstLayerBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  playerSymbol = "";
  computerSymbol = "";

  isPlayersTurn = false;
  gameOver = false;

  messages.innerHTML = "";

  display();
}
