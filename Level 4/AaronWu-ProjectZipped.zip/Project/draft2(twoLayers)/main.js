function initialize() {
  gameContainer = document.getElementById("gameContainer");
  startScreenDisplay = document.getElementById("startScreen");
  messages = document.getElementById("messages");

  // 0 for empty, 'x' and 'o' will be used for each player
  firstLayerBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  secondLayerBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0];

  // keep track of how many turns a square is taken so the opposite
  // player can't take a spot immediately after the other player took it
  turnsOccupied = [0, 0, 0, 0, 0, 0, 0, 0, 0];

  // player will choose if they want to be X or O
  playerSymbol = "";
  computerSymbol = "";

  isPlayersTurn = false;
  gameOver = false;

  display();
}

function initializePlayer(sym) {
  playerSymbol = sym;

  // X always goes first
  if (playerSymbol == "x") {
    isPlayersTurn = true;
    computerSymbol = "o";
  } else {
    isPlayersTurn = false;
    computerSymbol = "x";
    computerMakesMove();
  }

  display();
}

function makeMove(pos) {
  if (gameOver) return;
  if (!isPlayersTurn) return;

  var validMove = false;

  // let player play on the any layer if it is empty
  if (firstLayerBoard[pos] == 0) {
    firstLayerBoard[pos] = playerSymbol;
    validMove = true;
  } else if (secondLayerBoard[pos] == 0) {
    // if the first layer is the player's then claim it for good, else take it away from the other player
    if (firstLayerBoard[pos] == playerSymbol) {
      secondLayerBoard[pos] = playerSymbol;
      validMove = true;
    } else {
      // can only take away other player's square if it is not recently claimed
      if (turnsOccupied[pos] > 1) {
        firstLayerBoard[pos] = playerSymbol;
        turnsOccupied[pos] = 0;
        validMove = true;
      }
    }
  }

  if (validMove) {
    checkGameOver();
    updateOccupiedList();

    isPlayersTurn = false;
    computerMakesMove();
  }

  display();
}

function computerMakesMove() {
  if (gameOver) return;
  var legalMove = false;
  var i = 0;

  while (!legalMove) {
    var randomPos = Math.floor(Math.random() * 9);

    /* the move is allowed if the firstLayer is untaken */
    if (firstLayerBoard[randomPos] == 0) {
      legalMove = true;
      firstLayerBoard[randomPos] = computerSymbol;
    } else if (secondLayerBoard[randomPos] == 0) {
      if (firstLayerBoard[randomPos] == computerSymbol) {
        secondLayerBoard[randomPos] = computerSymbol;
        legalMove = true;
      } else {
        if (turnsOccupied[randomPos] > 1) {
          firstLayerBoard[randomPos] = computerSymbol;
          turnsOccupied[randomPos] = 0;
          legalMove = true;
        }
      }
    }

    i++;
    if (i > 150) {
      console.log("too many loops");
      break;
    }
  }

  checkGameOver();
  updateOccupiedList();
  isPlayersTurn = true;

  display();
}

function updateOccupiedList() {
  for (var i = 0; i < firstLayerBoard.length; i++) {
    if (firstLayerBoard[i] != 0) {
      turnsOccupied[i] += 1;
    }
  }
}

function checkGameOver() {
  // helper function will return true if the list has the same items at index a, b, and c
  function helper(list, a, b, c) {
    if (list[a] == list[b] && list[b] == list[c]) {
      if (list[a] != 0 && list[b] != 0 && list[c] != 0) {
        return true;
      }
    } else {
      return false;
    }
  }

  if (helper(firstLayerBoard, 0, 1, 2) || helper(firstLayerBoard, 0, 3, 6)) {
    endGame(firstLayerBoard[0]);
  }

  if (helper(firstLayerBoard, 2, 5, 8) || helper(firstLayerBoard, 6, 7, 8)) {
    endGame(firstLayerBoard[8]);
  }

  if (helper(firstLayerBoard, 1, 4, 7) || helper(firstLayerBoard, 3, 4, 5)) {
    endGame(firstLayerBoard[4]);
  }

  if (helper(firstLayerBoard, 0, 4, 8) || helper(firstLayerBoard, 2, 4, 6)) {
    endGame(firstLayerBoard[4]);
  }

  /* check if there is a tie */
  if (!gameOver) {
    // determine if the next player can play anything
    var currentPlayerSymbol = isPlayersTurn ? computerSymbol : playerSymbol;
    var legalMove = false;
    var i = 0;
    while (!legalMove) {
      var randomPos = Math.floor(Math.random() * 9);

      /* the move is allowed if the firstLayer is untaken */
      if (firstLayerBoard[randomPos] == 0) {
        legalMove = true;
      } else if (secondLayerBoard[randomPos] == 0) {
        if (firstLayerBoard[randomPos] == currentPlayerSymbol) {
          legalMove = true;
        } else {
          if (turnsOccupied[randomPos] > 1) {
            legalMove = true;
          }
        }
      }

      if (i > 150) {
        break;
      }
      i++;
    }
    if (!legalMove) endGame("tie");
  }

}

function endGame(winner) {
  gameOver = true;
  if (playerSymbol == winner) {
    messages.style.color = "#14fc03";
    messages.innerHTML = "You win!";
  } else if (computerSymbol == winner) {
    messages.style.color = "#fc0320";
    messages.innerHTML = "You lose!";
  } else if (winner == "tie") {
    messages.style.color = "#fcd303";
    messages.innerHTML = "It's a tie!";
  }
}

function display() {
  // start the game if player has chosen their symbol
  if (playerSymbol != "") {
    startScreenDisplay.style.display = "none";
    gameContainer.style.display = "block";
  } else {
    startScreenDisplay.style.display = "block";
    gameContainer.style.display = "none";
  }

  for (var i = 0; i < firstLayerBoard.length; i++) {
    var currentPos = document.getElementById("position" + i);

    if (firstLayerBoard[i] == 0) {
      currentPos.innerHTML = "";
    } else if (firstLayerBoard[i] == "x") {
      currentPos.innerHTML = "X";
      if (secondLayerBoard[i] == "x") currentPos.style.backgroundColor = "#9bff85";
    } else if (firstLayerBoard[i] == "o") {
      currentPos.innerHTML = "O";
      if (secondLayerBoard[i] == "o") currentPos.style.backgroundColor = "#9bff85";
    }
  }
}

function reset() {
  firstLayerBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  secondLayerBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  turnsOccupied = [0, 0, 0, 0, 0, 0, 0, 0, 0];

  playerSymbol = "";
  computerSymbol = "";

  isPlayersTurn = false;
  gameOver = false;

  messages.style.color = "black";
  messages.innerHTML = "";

  // reset the background colors for each square
  for (var i = 0; i < firstLayerBoard.length; i++) {
    var currentPos = document.getElementById("position" + i);
    currentPos.style.backgroundColor = "white";
  }

  display();
}
