function getValidMoves() {
  // returns a list of the possible positions to play
  var validMoves = [];

  for (var i = 0; i < 9; i++) {
    if (firstLayerBoard[i] == 0) {
      validMoves.push(i);
    } else if (secondLayerBoard[i] == 0) {
      if (firstLayerBoard[i] == computerSymbol) {
        validMoves.push(i);
      } else {
        if (turnsOccupied[i] > 1) {
          validMoves.push(i);
        }
      }
    }
  }

  return validMoves;
}

// function getEnemyPosition() {
//   var enemySquares = [];

//   for (var i = 0; i < 9; i++) {
//     if (firstLayerBoard[i] == playerSymbol) enemySquares.push(i);
//   }
// }

function checkHowCloseToWinning(currentMove, symbol, firstLayer, secondLayer) {
  function positionChecker(a, b, c) {
    var movesAwayFromWinning = 3;

    if (firstLayer[a] == symbol) {
      movesAwayFromWinning--;
    }
    if (firstLayer[b] == symbol) {
      movesAwayFromWinning--;
    }
    if (firstLayer[c] == symbol) {
      movesAwayFromWinning--;
    }

    // return 2 times the moves to use as a score
    // return a lower score if the symbol is 1 move away from winning
    if (movesAwayFromWinning < 2) {
      return 2 * movesAwayFromWinning - 3;
    } else {
      return 2 * movesAwayFromWinning;
    }
  }

  var score = 0;

  // score += positionChecker(0, 1, 2);
  // score += positionChecker(0, 3, 6);

  // score += positionChecker(2, 5, 8);
  // score += positionChecker(6, 7, 8);

  // score += positionChecker(1, 4, 7);
  // score += positionChecker(3, 4, 5);


  // score += positionChecker(0, 4, 8);
  // score += positionChecker(2, 4, 6);

  if (currentMove >= 0 && currentMove <= 2) {
    score += positionChecker(0, 1, 2);
    score += positionChecker(currentMove, currentMove + 3, currentMove + 6);

    if (currentMove == 0) score += positionChecker(0, 4, 8);
    else if (currentMove == 2) score += positionChecker(2, 4, 6);
    else score += 6;

  } else if (currentMove >= 3 && currentMove <= 5) {
    score += positionChecker(3, 4, 5);
    score += positionChecker(currentMove, currentMove + 3, currentMove - 3);
    if (currentMove == 4) score += positionChecker(0, 4, 8);
    else score += 6;

  } else if ((currentMove >= 6 && currentMove <= 8)) {
    score += positionChecker(6, 7, 8);
    score += positionChecker(currentMove, currentMove - 3, currentMove - 6);

    if (currentMove == 6) score += positionChecker(2, 4, 6);
    else if (currentMove == 8) score += positionChecker(0, 4, 8);
    else score += 6;
  }

  return score;
}

function bestMoveToPlay() {
  // all scores of each possible move
  var possibleOutcomes = [];

  // var enemySquares = getEnemyPosition();
  validMoves = getValidMoves();

  // play out each move and see how close player is to winning
  for (var i = 0; i < validMoves.length; i++) {
    var possibleFirstLayerBoardState = [...firstLayerBoard];
    var possibleSecondLayerBoardState = [...secondLayerBoard];

    // play out the move
    if (possibleFirstLayerBoardState[validMoves[i]] == 0) possibleFirstLayerBoardState[validMoves[i]] = computerSymbol;
    else possibleSecondLayerBoardState[validMoves[i]] = computerSymbol;

    possibleOutcomes.push(checkHowCloseToWinning(validMoves[i], playerSymbol, possibleFirstLayerBoardState, possibleSecondLayerBoardState));
  }
  console.log(possibleOutcomes)
  var index = possibleOutcomes.indexOf(Math.min(...possibleOutcomes));
  return validMoves[index];
  // return possibleOutcomes;
}

function computerSmartMakeMove() {
  // var possibleOutcomes = bestMoveToPlay();


  // use second layer if it doesnt work
  var best = bestMoveToPlay();
  if (firstLayerBoard[best] == 0) {
    takeSquare(1, best);
  } else if (firstLayerBoard[best] == computerSymbol) {
    takeSquare(2, best);
  } else if (turnsOccupied[best] > 1) {
    takeSquare(1, best, resetTurnsOccupied=true);
  }


  checkGameOver();
  updateOccupiedList();
  isPlayersTurn = true;

  display();
}
